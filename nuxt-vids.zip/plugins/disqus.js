import Vue from "vue";
import VueDisqus from "vue-disqus";

Vue.use(VueDisqus);
