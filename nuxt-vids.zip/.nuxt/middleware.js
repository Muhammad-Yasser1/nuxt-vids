const middleware = {}

middleware['HasTokenAndAdmin'] = require('@/middleware/HasTokenAndAdmin.js');
middleware['HasTokenAndAdmin'] = middleware['HasTokenAndAdmin'].default || middleware['HasTokenAndAdmin']

middleware['isAdmin'] = require('@/middleware/isAdmin.js');
middleware['isAdmin'] = middleware['isAdmin'].default || middleware['isAdmin']

export default middleware
