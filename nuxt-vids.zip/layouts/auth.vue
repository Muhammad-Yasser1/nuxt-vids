<template>
    <div class="container-fluid px-md-5">
        <nuxt/>
    </div>
</template>

<script>
export default {};
</script>

<style>
</style>
