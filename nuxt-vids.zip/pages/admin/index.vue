<template>
    <h1 class="text-center my-3">Select Video</h1>
</template>

<script>
export default {};
</script>

<style>
</style>
