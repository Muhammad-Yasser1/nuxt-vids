<template>
    <h1>Contact Us Page</h1>
</template>

<script>
export default {};
</script>

<style scoped>
</style>